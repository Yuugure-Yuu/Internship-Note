在正式服可生成对PgSQL某表的查询API（因一个新版本bug，测试服和本地暂不可）。

请求Body为：

```json
{
  "dbConfig":{
    "dbType": "PostgreSql",
    "ip": "10.0.102.47",
    "port": 5432,
    "dbName": "aiit_talent_pool"
	},
  "opDetail":{
	"tableName": ["main_talent"],
    "operation": "all",
	"modelName": "public"
  }
}

```

![avatar](VC}{@0S3@E`63ENYQ~~@LE4.PNG)

生成API密文为：

```
aA06fWRthnwLhs81anDS2xI6aPpcHbkrPDp74-NJTuH4FesnbQqiOIHHZcEOZmjv7wxBxqrJY1U7oZwC9d6t7hoFy6-sNwfMSBFs9jZFEIclGLcvNV4IoPL18Taha9PIMxw-hr1A8FI1QvqRo8dJra2u5BglU4o7_yLJGalqwepLVcekCFwI8Nnsnk027S7OjWjvCArc6fE2dSMEMUaQOcxUqi7Qy6inwVIRON58nCN66fIZykKR2F-BU64FmJITwP4gmkSoVrizOZY8_Kxxgkz2i7jmDgt_AKEdlWAEWOarvfM_ig2cOpxsOJWgz3T3Ry0gs8nR8bup9t5np778GA==
```

可以通过master分支最新代码在本地成功使用该API（因一个老版本bug，正式服暂不可用）：

![avatar](JDR0ZFU8GU]R1UPLT9_J_2.PNG)

目前测试服部署的代码与master分支最新代码完全一致，但是在测试服访问时会出现除零异常。![avatar](UMI~`ZN7G9PI1X]%ZPL}@@F.PNG)

错误信息为：

![avatar](A1FS~KMGD$]4B%IFT{QX~DX.PNG)

即在ApiQueryServiceImpl.java此处调用的fastjson函数报错：

![avatar](4MMWVJ[T5RMGOFI~]5{CWK.PNG)

但在本地却未出现此异常，网上未找到fastjson类似出错。